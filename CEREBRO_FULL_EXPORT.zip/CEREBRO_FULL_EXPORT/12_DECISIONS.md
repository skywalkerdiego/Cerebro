# Decisiones — Cerebro

Extraídas literalmente de README.md, CLAUDE.md, logros.md y los archivos de `metas/`/`perfil/`. Clasificadas como:

- **CONFIRMED** — decisión tomada y en vigor, con fecha.
- **PROPOSED** — sobre la mesa, sin resolver.
- **SUPERSEDED** — reemplazada por una decisión posterior.
- **REJECTED** — evaluada y descartada explícitamente.

---

## Arquitectura y gobierno del sistema

- **CONFIRMED (sin fecha exacta, vigente en CLAUDE.md)**: los `.md` son la fuente de verdad; los tableros se regeneran a partir de ellos, nunca al revés.
- **CONFIRMED**: cada cambio real en `metas/`, `perfil/`, `finanzas/` o `desempeno/` que afecte un tablero publicado se republica en la misma sesión, sin que Diego lo pida — pero no todos los tableros, solo los que cambiaron.
- **CONFIRMED (excepción, en `.claude/skills/dinero/SKILL.md`)**: para gastos capturados por la skill `/dinero`, Finanzas.exe NO se republica automáticamente — se pregunta primero.
- **CONFIRMED 01/09/2026**: Pendientes.exe se retira (se desactualizaba solo); su contenido pasa a "Pendientes vivos" dentro de Rutina.exe.
- **CONFIRMED 31/08/2026 → SUPERSEDED 01/09/2026**: la primera fusión de Aspect.exe en Rutina.exe (31/08) dejó solo un checklist genérico y perdió la línea de tiempo real del día. Se corrigió el 01/09 reponiendo la línea de tiempo con casillas reales.
- **CONFIRMED 31/08/2026**: Eventos.exe se fusiona en Calendario.exe.
- **CONFIRMED 31/08/2026**: Habilidades.exe se fusiona en Yo.exe. *(Nota de esta auditoría: `perfil/hoy.md` sigue enlazando a Habilidades.exe como si fuera independiente — referencia no corregida, ver `13_ISSUES.json` #3 y el registro de Habilidades.exe en `06_ARTIFACTS.json`.)*
- **CONFIRMED 09/09/2026**: el plan del Vaivén se separa de Calendario.exe a su propio tablero, Vaivén.exe — excepción deliberada a la regla de consolidar, porque un plan de viaje completo necesita su propio espacio.
- **CONFIRMED 10-11/09/2026 (dos vueltas)**: Cerebro.exe se rediseña de "cyberpunk" a un sistema tipo Linear/Arc — primero solo el sistema visual, luego la composición completa (dock de navegación inferior). Documentado también en los turnos previos de esta misma conversación.

## Titulación

- **CONFIRMED 05/09/2026**: trámite en pausa — podría no aplicar "por promedio" si ya pasaron 2 años desde el egreso. No pagar la ficha ($620) ni firmar nada hasta tener respuesta.
- **CONFIRMED 09/09/2026**: David García Contreras (Jefe de Carrera) respondió que van a hacer una consulta interna — **no es la respuesta final**, la pausa sigue vigente.
- **PROPOSED, sin dato**: falta la fecha exacta de egreso de Diego para calcular con precisión si ya pasaron los 2 años.

## Trabajo

- **CONFIRMED 31/08/2026**: búsqueda de trabajo pasa a "modo mantenimiento" — 1-2 vacantes en la comida, nada de bloques largos, para liberar espacio a titulación y desempeño.
- **CONFIRMED 31/08/2026**: el criterio para romper el modo mantenimiento es que una vacante cumpla 2 de 3 (sube el sueldo claramente / es remota o recorta el traslado / el salario cotizado ante el IMSS es bueno).
- **REJECTED 31/08/2026**: la oferta de NC Recruitment/American Express — Diego decidió no seguir el proceso (motivo no registrado).
- **CONFIRMED 05/09/2026**: 4 rutas de búsqueda fijas guardadas, para no empezar de cero cada vez.

## Ahorro / patrimonio

- **CONFIRMED 15/08/2026**: fondo conjunto de $47,000 con Fanny, meta antes de Navidad 2026, aporte proporcional al ingreso de cada quien.
- **CONFIRMED 01/09/2026**: el fondo, al llegar a $47,000, **no se cierra** — sigue creciendo como un solo fondo patrimonial que se reparte a la siguiente meta (boda 2027, luego casa 2028+).
- **CONFIRMED 01/09/2026**: orden del horizonte de vida: mudanza (2026) → boda (2027) → casa propia (2028+) → familia. Esto corrigió una versión anterior del archivo que ponía la boda después de la casa.
- **CONFIRMED 01/09/2026**: la boda es la prioridad #1 de 2027, antes que cambio de coche y fondo de emergencia.
- **REJECTED 31/08/2026**: trabajar el Chevy en Uber — no califica por año-modelo y no hay horas disponibles en la semana real de Diego.
- **REJECTED 31/08/2026**: préstamo Fonacot mientras el cambio de trabajo siga en el horizonte (riesgo de deuda de nómina no portable).
- **CONFIRMED 05/09/2026**: el Chevy se arregla (no se cambia ni se vende todavía) hasta después de la mudanza.
- **CONFIRMED 05/09/2026 (resuelto)**: ventilador y radiador del Chevy arreglados — sin riesgo de sobrecalentamiento pendiente.

## Rutina / reglas del sistema

- **CONFIRMED 31/08/2026**, tras una caída de productividad reportada por Diego: 3 reglas — (1) máximo 3 pistas activas a la vez, (2) lo urgente desplaza el foco de la noche, no se apila, (3) una noche libre por semana sin foco asignado.
- **CONFIRMED 31/08/2026**: las 3 pistas activas son Titulación, Desempeño en Boost, Italiano. Todo lo demás en standby explícito (no cancelado).

## Aprendizaje

- **CONFIRMED 31/08/2026, arranque 01/09/2026**: italiano vía Duolingo, 1 lección diaria en el Break 1, con la racha (no el tiempo) como única métrica.
- **CONFIRMED**: cultura general/lectura en standby consciente hasta que la titulación se resuelva.

## Perfil / relaciones

- **CONFIRMED (varias fechas de agosto 2026)**: Diego vive con sus papás; tiene amigos cercanos del trabajo pero le falta vida social fuera de él; ya no va a terapia regularmente (aunque hubo una sesión puntual el 20-21/08).
- **PROPOSED, sin fecha**: explorar psicología como camino académico en serio — Diego mismo reconoce que su dificultad de atención es un obstáculo real a planear, no a ignorar.

## Viaje a la cabaña (28-30/08/2026)

- **CONFIRMED 29/08/2026**: cancelado — falló el Aveo de la mamá de Diego (no el Chevy). Sin pérdida de dinero porque la cabaña se pagaba en el hotel.
- **PROPOSED, sin fecha**: decidir con Fanny si se reagenda la escapada.
