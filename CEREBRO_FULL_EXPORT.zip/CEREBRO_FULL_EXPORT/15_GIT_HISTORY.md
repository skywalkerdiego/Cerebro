# Historial de Git — Cerebro

**Advertencia de completitud:** este repo es un clon superficial (`shallow`) — existe un archivo `.git/shallow` y el commit más antiguo del log aparece marcado `(grafted)`. El log de abajo es todo lo que este checkout puede ver; no se puede garantizar que no exista historia anterior fuera del shallow clone.

- Rama actual en el momento de la exportación: `claude/eager-maxwell-jxj88u`
- HEAD: ver `GIT/HEAD_at_export_time.txt`
- Remoto: `https://github.com/skywalkerdiego/Cerebro`
- Ramas presentes: `main`, `claude/eager-maxwell-jxj88u` (+ sus `remotes/origin/*`)
- Tags: ninguno
- Total de commits visibles: 96
- Log completo con archivos tocados por commit: `GIT/full_log_with_stats.txt`
- Log compacto (hash|fecha|asunto): `GIT/log_compact.txt`
- Solo merges (marcan el cierre de cada PR): `GIT/merges.txt`
- Búsqueda de archivos borrados/renombrados en todo el historial: `GIT/deleted_files_history.txt` y `GIT/renamed_files_history.txt` — **ambos vacíos**. Esto confirma un hecho arquitectónico importante: **nunca se ha borrado ni renombrado un archivo de datos en este repo** — todas las "fusiones" de tableros (Aspect.exe→Rutina.exe, Eventos.exe→Calendario.exe, Habilidades.exe→Yo.exe, retiro de Pendientes.exe/Tiempo.exe) ocurrieron **solo del lado de los Artifacts en claude.ai**, nunca tocaron archivos del repo — el código de esos tableros retirados simplemente no se volvió a publicar, pero el `.md` correspondiente se reescribió in-place, nunca se movió ni se eliminó.

## Commits agrupados por tema (curado de `log_compact.txt`, no exhaustivo — priorizados según lo pedido: arquitectura, tableros, Artifacts, UI, funcionalidades, migraciones, bugs, decisiones de diseño)

### Arquitectura / reorganización del sistema
- `5346fc7` Reajuste del sistema: 3 pistas activas, horizontes y patrimonio
- `cbd1bce` (#14) Auditoría del sistema: hoja de personaje RPG y cierres de datos
- `6a0be9b` Consolida Aspect/Tiempo/Pendientes.exe en Rutina.exe
- `f267297` Consolida Aspect/Tiempo/Pendientes.exe en Rutina.exe (segunda pasada, con la línea de tiempo real repuesta)
- `9425884` Detalla la ruta del domingo 23/08 y agrega regla de sincronizar tableros automáticamente *(origen de la regla que hoy vive en CLAUDE.md)*
- `4145511` Cierra el hueco de finanzas, confirma horario Kronos y suma gustos de papá y patrón de sueño *(HEAD de `main`)*

### Tableros / Artifacts (creación, fusión, separación)
- `9222034` Extiende Periódico.exe a los 3 briefs diarios (5am/5:30pm/8pm)
- `9f29b9d` Cancela el cine, ajusta cabaña y agrega Periódico.exe (brief 5am) — **creación de Periódico.exe**
- `5fec819`/`38391e0` Agrega Descubre.exe y actualiza noticias con datos reales
- `815aa74` Arma Calendario.exe y Aspecto.exe con acceso directo desde el HUD
- `65f4408` Renombra Aspecto.exe a Aspect.exe
- `bf3e9bb` Arma Artículos.exe (checklist de investigación y banco de ideas)
- `4fbce31` Arma la skill /revisemos-cerebro
- `5d03329` Agrega Acta Patrimonial: tablero del horizonte casa/boda/familia
- `c823d45` Separar el plan del Vaivén a su propio tablero (Vaivén.exe)
- `3fc48f1` (#31) Agregar skill dinero para captura rápida de gastos
- `fe1e012` Rediseño visual de Cerebro.exe: de cyberpunk a sistema Linear/Arc
- `bc65286` Cerebro.exe: rediseño de layout con dock inferior tipo Linear móvil *(HEAD de la rama de trabajo, esta misma conversación)*

### Funcionalidades / datos
- `234db9e` Integrar agua/rellenar botella en los 3 breaks del turno
- `38a759d` Arma el trackeo en vivo del saldo de la quincena
- `bd1a2a5` (#19) Finanzas.exe abre con los 3 números y cuadra con los saldos reales
- `4afb120` Remapea la semana del 07 al 13/09 y corrige el timing de la nómina

### Bugs / correcciones
- `e7887f0` Corregir fechas desfasadas y marcar el radiador como atrasado
- `07064ff` Registra cancelación del viaje a la cabaña (falló el Aveo de mamá, no el Chevy) — corrige una atribución errónea previa
- `2d4bd37` Corrige el efectivo real (~$300) y descarta el cambio de vales de despensa
- `5bc0041` Registra el retiro de $300 y reparte Santander para metro/combi/colchón — corrige un estimado de efectivo equivocado

### Decisiones de diseño / UX explícitas
- `e46078f`/`08b24ca` Cierra/registra el presupuesto de la quincena
- `e14aab6` Pone el sistema al día al 05/09/2026 y lo reordena para que se entienda
- `f0db21a` Ajusta el plan de hoy: sale a las 5pm con un amigo (Regla 2 de rutina.md en acción real)
- `54b17b5` Pausa la titulación: el trámite por promedio podría no aplicar
- `87a664b` Fusiona ramas abiertas sin mergear y corrige la historia real del viaje
- `ee5a7e7` Registra la unificación de ramas y la segunda pasada cyberpunk de Cerebro.exe como logro

## Patrón de flujo de trabajo observado

Casi todos los cambios sustantivos llegan por Pull Request a `main`, con ramas nombradas `claude/<slug-descriptivo>-<hash-corto>` — consistente con un flujo donde cada sesión de Claude Code trabaja en su propia rama y se mergea. Hay al menos 3 casos de ramas que quedaron sin mergear por un tiempo y se reconciliaron después a mano (`87a664b`, `9a59a6e`, `606c213`), documentados también como aprendizaje en `logros.md` ("Unificaste las ramas sueltas del repo a main").
