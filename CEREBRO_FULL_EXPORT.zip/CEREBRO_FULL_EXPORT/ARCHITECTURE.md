# Arquitectura real de Cerebro (versión legible — ver `03_ARCHITECTURE.json` para la versión estructurada)

```
                    ┌─────────────────────────────────┐
                    │   Diego (único usuario/escritor)  │
                    └───────────────┬───────────────────┘
                                    │ conversa en el chat
                                    ▼
                    ┌─────────────────────────────────┐
                    │        Claude (Claude Code)       │
                    │  agente que lee/escribe ambos lados │
                    └──────┬───────────────────┬────────┘
                           │                   │
              escribe/lee │                   │ Artifact:read / Artifact:publish
                           ▼                   ▼
        ┌───────────────────────────┐   ┌───────────────────────────────┐
        │   REPO GIT (skywalkerdiego/ │   │   CLAUDE ARTIFACTS (claude.ai)  │
        │   Cerebro) — FUENTE DE VERDAD│   │   39 páginas HTML/CSS/JS         │
        │                             │   │   standalone, NO están en git    │
        │  README.md, CLAUDE.md       │   │                                   │
        │  metas/*.md   (8)           │   │  Cerebro.exe (hub) ──┐            │
        │  perfil/*.md  (22)          │   │                       │            │
        │  finanzas/*.md (2)          │   │  ┌────────────────────┘            │
        │  desempeno/*.md (2)         │   │  ▼ enlaza a los 22 "boards"        │
        │  logros.md                  │   │  Periódico · Rutina · Hoy ·        │
        │  biblioteca/ (6 PDFs/imgs)  │   │  Calendario · Titulación ·         │
        │  .claude/skills/ (2)        │   │  Desempeño · Llamadas · Trabajo ·  │
        │                             │   │  Artículos · Finanzas · Mudanza ·  │
        │  = 46 archivos, 1.9 MB      │   │  Patrimonio · Compras · Nosotros · │
        └───────────────────────────┘   │  Recetario · Árbol · Perfil · Yo ·  │
                                          │  Logros · Carros · Biblioteca ·     │
                                          │  Descubre                          │
                                          │                                     │
                                          │  + 6 artifacts activos fuera de la  │
                                          │    nav (Vaivén, Combo Totalplay,    │
                                          │    Chao AT&T, Bitácora de Cabaña,   │
                                          │    Alerta de Sistema, Habilidades)  │
                                          │  + 9 huérfanos                     │
                                          └───────────────────────────────────┘
                                                          │
                                                          │ el navegador de Diego
                                                          ▼
                                          ┌───────────────────────────────────┐
                                          │  localStorage (por dispositivo,    │
                                          │  volátil) — checkboxes de Rutina,  │
                                          │  posibles datos semilla de         │
                                          │  Finanzas/Desempeño                │
                                          │  ⚠️ NUNCA escribe de vuelta al repo │
                                          └───────────────────────────────────┘
```

## Los tres hechos que más importan para quien continúe este proyecto

1. **El código de los tableros no está en git.** Está en claude.ai. Este repo, por sí solo, es solo datos + configuración de Claude Code. Si alguna vez se pierde el acceso a los Artifacts, se pierde el 100% del código de interfaz — solo quedarían los `.md`. Este export mitiga eso capturando 6 de 39 artifacts íntegros (ver `ARTIFACTS_SOURCE/`) y documentando el resto por metadata + URL en `06_ARTIFACTS.json`.

2. **La escritura es unidireccional y pasa siempre por Claude.** No hay una app ni un formulario donde Diego capture datos directamente al repo. Todo pasa por: Diego se lo cuenta a Claude en el chat → Claude edita el `.md` → Claude (a veces) republica el tablero. Los inputs interactivos de los propios tableros (checkboxes, campos) solo tocan `localStorage` del navegador — nunca vuelven al repo por sí solos.

3. **No hay un sistema de diseño único.** Coexisten al menos 4 lenguajes visuales (ver `11_DESIGN_SYSTEM.json`), producto de rediseños puntuales por sesión, sin un token compartido entre artifacts. Cualquier trabajo de "unificar el diseño" es un proyecto real, no un detalle.
