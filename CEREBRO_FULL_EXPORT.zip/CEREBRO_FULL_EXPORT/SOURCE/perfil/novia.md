# 💜 Fanny

**Nació:** 2001
**Casa de Hogwarts:** Ravenclaw
**Cumpleaños:** 20 de enero
**Aniversario como pareja:** 20 de octubre — cumplen 2 años el 20/10/2026
**Profesión:** Doctora (todavía sin especialidad definida)

Ver fechas con cuenta regresiva en
[fechas-importantes.md](fechas-importantes.md) e ideas de regalo en
[regalos-novia.md](regalos-novia.md).

## Cómo se conocieron

Se conocieron en la prepa — ella era su crush. Compartían la misma clase
de música. Diego describe la relación como sumamente intensa, en todos
los aspectos, y le gusta mucho escribirle y contarle lo que siente.

## Música

- Joji
- Gorillaz
- 21 Pilots
- Olivia Rodrigo
- **Su canción con Diego: "Disco", de Surf Curse.**
- Comparten mucho gusto musical con Diego — Kendrick Lamar, Gorillaz,
  Nirvana.

## Series y películas

- Game of Thrones
- *That 70s Show* — su sitcom favorita
- *Community*
- *Inglourious Basterds*
- Le encantan las películas y series en general
- *Peaky Blinders* y *Breaking Bad* — le gustan a los dos, algo que
  comparten con Diego

## Fandoms

- Harry Potter — le fascina, incluyendo fanfics relacionados
- Snoopy

## Familia

- Tiene dos hermanas menores, gemelas entre ellas — cumplen el 19 de
  junio.

## Mascota

- Tiene una perrita llamada **Tris**.

## Tatuaje en pareja

- Tiene un tatuaje a juego con Diego — mandala de loto/girasol: ella
  el contorno, Diego el relleno. Es el único de los tatuajes de Diego
  con un significado.

## Comida y bebida

- Le gusta comer sano, las ensaladas.
- También le gustan mucho los tacos.
- Le gusta el café y la cerveza.

## Cuidado personal

- Skincare, cuidado de cabello, cuerpo y salud en general
- Maquillaje
- Gimnasio
- Marcas que usa: Elf, Cerave, Dior

## Tallas

- Calzado: 4 (MX)
- Ropa: M

## Bienestar

- Le estresa: el trabajo, el dinero.
- Le relaja: que le den masaje y cariño.
- Cómo le gusta recibir cariño: que tengas detalles con ella, que le
  digas cosas (palabras), y contacto físico (que la acaricies).

## Notas

- Están perdidamente enamorados — no es solo un dato, es lo que más te
  importa ahora mismo, y vale la pena que este archivo lo refleje.
- La foto de los dos (evento formal, 15/08/2026) ya está incorporada en
  el dossier visual [Nosotros.exe](https://claude.ai/code/artifact/958d66cd-dbca-442a-b286-37994df7026e).
- Este archivo es un borrador armado con lo que me has contado —
  cuéntame más cuando quieras y lo voy sumando.
