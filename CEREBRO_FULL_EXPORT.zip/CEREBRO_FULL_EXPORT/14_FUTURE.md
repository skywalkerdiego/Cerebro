# Futuro / ideas propuestas (FUTURE / PROPOSED)

Nada de esto está implementado. Se documenta por separado porque el usuario lo pidió explícitamente — **no implementar nada de aquí sin que Diego lo pida**.

## Sobre el propio sistema Cerebro

- **PROPOSED** (esta conversación, turno de "rediseño premium"): convertir Cerebro.exe en un producto con persistencia real vía la capacidad `db` de Claude Artifacts — permitiría que lo que Diego marque en cualquier tablero (checkboxes, montos) se guarde del lado del servidor, visible entre dispositivos y legible por Claude en la siguiente sesión, en vez de vivir solo en `localStorage` del navegador.
- **PROPOSED**: unificar la tabla `WEEK` (horario Kronos) en una sola fuente en vez de las 3 copias divergentes actuales (Cerebro.exe, Rutina.exe, Periódico.exe) — ver `13_ISSUES.json` #1.
- **PROPOSED**: un sistema de diseño único compartido entre los 22 tableros, en vez de los ≥4 lenguajes visuales actuales — ver `11_DESIGN_SYSTEM.json`.
- **PROPOSED**: navegación por "vistas" (Hoy / Atención / Tableros / Yo) en vez de un solo documento largo con scroll — evaluado y parcialmente descartado en la auditoría de rediseño de esta misma conversación, por tensión con la regla de "todo a la vista" que ya llevó a Diego a consolidar tableros antes.
- **PROPOSED**: marcar bloques del día / posponer alertas directamente desde Cerebro.exe (hoy son de solo lectura, enlazan a otro tablero).
- **PROPOSED**: generar el horario semanal (`WEEK`) a partir de un patrón + excepciones, para que no caduque cada 7 días.
- **PROPOSED (explícitamente evaluado y NO instalado todavía)**: un stack de hasta 8 skills externas de Claude Code para diseño/frontend/accesibilidad/refactor seguro (`webapp-testing`, `web-design-guidelines` de Vercel, una skill de refactor seguro, el plugin `design` del marketplace `knowledge-work-plugins`, y opcionalmente `mobile-app-ui-design` y `modern-web-guidance`) — propuesto con comandos de instalación exactos, pendiente de la confirmación de Diego.

## Sobre la vida de Diego (documentadas en los `.md`, no implementadas)

- **PROPOSED**: convertir el 5% de aportación INFONAVIT + puntos + antigüedad en un plan formal de crédito de vivienda combinado con Fanny ("Unamos Créditos") — depende de que Fanny revise su elegibilidad en ISSEMyM.
- **PROPOSED, sin monto**: definir con Fanny un monto objetivo para la boda de 2027.
- **PROPOSED**: cambiar el Chevy por una moto (Vento o Italika 250cc) o coche nuevo con Fanny, después de la mudanza de 2026.
- **PROPOSED**: fondo de emergencia, después de cubrir la boda de 2027.
- **PROPOSED, arranca cuando haya rato libre, sin meta diaria**: aprender lo básico de mantenimiento del hogar (plomería/electricidad ligera).
- **PROPOSED, en standby**: retomar cultura general/lectura, artículos de investigación, y la posibilidad de una maestría (Estudios Latinoamericanos, RI, Economía Internacional u otra afín) — o explorar psicología como segunda carrera.
- **PROPOSED, standby explícito**: automatización/sistema para conectar con proveedores de importación/exportación — "proyecto de investigación paralelo", no plan principal.
- **PROPOSED**: publicar el primer artículo de investigación ("El giro a la derecha en América Latina") una vez que LinkedIn esté al día y las primeras vacantes aplicadas.
- **PROPOSED, sin fecha**: reagendar la escapada a cabaña con Fanny, cancelada el 29/08/2026.
- **PROPOSED**: certificación de inglés (TOEFL) — no urgente, mencionada como posible paso a futuro.
- **PROPOSED**: decidir sobre el cambio a Totalplay (paquete con streaming) y a un plan familiar Telcel de 4 líneas — investigación ya hecha en `perfil/servicios.md`, decisión pendiente.
